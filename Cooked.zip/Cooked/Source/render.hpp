/*!
@ All content 2025 DigiPen (SINGAPORE) Corporation, all rights reserved
@file render.hpp
@author1 Elvis lim sheng jie(elvisshengjie.lim)
@author2 Justin Kong (yimo.kong)
@author3 Kerrin Lemin Khoo (kerrinlemin.k)
@author4 Norman Chan (chan.f)
@course csd1451s25 Software Engineering Project 2
@section a
*//*______________________________________________________________________*/
// render.hpp
#pragma once

#include <AEEngine.h> // Include necessary headers first
#include <vector>
#include "Ingredients.hpp"
#include "player.hpp"
#include <AEGraphics.h>
#include <assert.h>
#include <crtdbg.h> // To check for memory leaks
#include <math.h> 
#include <vector>
#include <string>
#include "utils.hpp"



// Define Rect class before any function declarations
class Rect {
public:
    float width{};
    float height{};
    float x{};
    float y{};
};

////////////////////////////helper functions//////////////////
AEGfxVertexList* CreateMesh();
void DrawRect(Rect, unsigned int, AEGfxVertexList*);
void DrawRect(Rect, AEGfxTexture*, AEGfxVertexList*);
// ... Other boxes ...

// Forward declare your rendering functions

// Function declarations using Rect
void RenderMain_menu_background(AEGfxVertexList* mesh, AEGfxTexture* tex);
void RenderMain_digipenLogo(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Renderchicken(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Renderbeef(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Rendercheese(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Renderrice(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Renderpotato(AEGfxVertexList* mesh, AEGfxTexture* tex);
//void Renderegg(AEGfxVertexList* mesh, AEGfxTexture* tex);
void Renderbackground(AEGfxVertexList* mesh, AEGfxTexture* tex);
void RenderDustbin(AEGfxVertexList* mesh, AEGfxTexture* tex);
void RenderIngredientbox(AEGfxVertexList* mesh, AEGfxTexture*);
void RenderStove(AEGfxVertexList* mesh,Stove& stove, player& Player, const QTE& qteGauge, AEGfxTexture* stoveTex, AEGfxTexture* stoveDirty, AEGfxTexture* stoveCook);
void RenderCollisionBox(AEGfxVertexList* mesh, const Rect& box);
void RenderhighlightIngredientBox(AEGfxVertexList* mesh, const Rect& highlightBox);
void RenderQTEGauge(AEGfxVertexList* mesh, const QTE& qteGauge, AEGfxTexture* barTex, AEGfxTexture* sliderTex,  AEGfxTexture* targetTex);

void RenderRecipeBox(AEGfxVertexList* mesh, AEGfxTexture* tex, const Recipe& recipe, float x, float y,
    AEGfxTexture* chickenTex, AEGfxTexture* beefTex, AEGfxTexture* cheeseTex,
    AEGfxTexture* eggTex, AEGfxTexture* riceTex, AEGfxTexture* potatoTex);

void RenderActiveRecipes(AEGfxVertexList* mesh, AEGfxTexture* tex, const RecipeSystem& recipeSystem,
    AEGfxTexture* chickenTex, AEGfxTexture* beefTex, AEGfxTexture* cheeseTex,
    AEGfxTexture* eggTex, AEGfxTexture* riceTex, AEGfxTexture* potatoTex);

void renderStoveIngredient(AEGfxVertexList* mesh, AEGfxTexture* chickenTex, AEGfxTexture* eggTex, AEGfxTexture* cheeseTex, AEGfxTexture* riceTex, AEGfxTexture* beefTex, AEGfxTexture* potatoTex, Stove& stove);

void displayScore(int);
void displayTimer(double);
void mouseDeviceRender(AEGfxVertexList* mesh, AEGfxTexture*);
//Font
void InitFont();
void DestroyFront();
//void RenderIngredientsOnBoxes(AEGfxVertexList* mesh);
void RenderIngredientsOnBoxes(
    AEGfxVertexList* mesh,
    AEGfxTexture* chickenTex,
    AEGfxTexture* beefTex,
    AEGfxTexture* cheeseTex,
    AEGfxTexture* eggTex,
    AEGfxTexture* riceTex,
    AEGfxTexture* potatoTex);

// Extern declarations for global variables
extern Rect backgroundRect;
extern Rect dustbinRect;
extern Rect ingredientBoxRect;
extern std::vector<Rect> highingredientBoxes;
extern std::vector<Rect> collisionBoxes;
extern std::vector<Rect> objectcollision;
extern s8 FontID;
extern Rect mouseDevice;
//extern s8 FontID_main_menu;