<?php

$config = array(
  'PROJECT_NAME' => "Alpha Engine v3.11",
  'GENERATE_TREEVIEW' => true,
  'DISABLE_INDEX' => false,
);

$translator = array(
  'search_results_title' => "Search Results",
  'search_results' => array(
    0 => "Sorry, no documents matching your query.",
    1 => "Found <b>1</b> document matching your query.",
    2 => "Found <b>\$num</b> documents matching your query. Showing best matches first.",
  ),
  'search_matches' => "Matches:",
  'search' => "Search",
  'split_bar' => "<div id=\"side-nav\" class=\"ui-resizable side-nav-resizable\">\n  <div id=\"nav-tree\">\n    <div id=\"nav-tree-contents\">\n      <div id=\"nav-sync\" class=\"sync\"></div>\n    </div>\n  </div>\n  <div id=\"splitbar\" style=\"-moz-user-select:none;\" \n       class=\"ui-resizable-handle\">\n  </div>\n</div>\n<script type=\"text/javascript\">\n/* @license magnet:?xt=urn:btih:d3d9a9a6595521f9666a5e94cc830dab83b65699&amp;dn=expat.txt MIT */\n$(function(){initNavTree('search.html',''); initResizable(true); });\n/* @license-end */\n</script>\n<div id=\"doc-content\">\n",
  'logo' => "Generated on Mon May 27 2024 22:05:26 for Alpha Engine v3.11 by&#160;\n<a href=\"https://www.doxygen.org/index.html\">\n<img class=\"footer\" src=\"doxygen.svg\" width=\"104\" height=\"31\" alt=\"doxygen\"/></a> 1.11.0 ",
);

?>
